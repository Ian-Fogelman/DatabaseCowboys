﻿#run under Powershell shell under Admin privileges

#cd "C:\Users\Ian\Desktop\AWS Presentation"

#pip install virtualenv

#python -m virtualenv .

#dir

#set-executionpolicy remotesigned

#cd "C:\Users\XXX\Desktop\AWS Presentation\Scripts"

#/Active.ps1

#pip install bs4

#deactivate
